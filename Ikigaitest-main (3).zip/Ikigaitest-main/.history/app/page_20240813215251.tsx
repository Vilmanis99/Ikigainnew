import PersonalityTest from './components/PersonalityTest';


export default function Home() {
  return (
    <div>
      <PersonalityTest />
    </div>
  );
}
